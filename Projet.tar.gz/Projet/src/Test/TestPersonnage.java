package Test;

public class TestPersonnage {

}
