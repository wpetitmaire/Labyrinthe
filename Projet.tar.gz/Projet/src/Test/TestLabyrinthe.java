package Test;

public class TestLabyrinthe {

}
