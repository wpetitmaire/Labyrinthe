package Labyrinthe;

public enum etatDuJeu {
	JEU, ARRIVEE, GAME_OVER, TERMINE;
}
